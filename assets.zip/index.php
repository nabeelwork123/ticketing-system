<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="author" content="">
	<meta name="robots" content="">
	<title>Ticketing System</title>


	<?php include 'includes/style.php'; ?>

</head>

<body>

	<!-- Main Wrapper -->
	<div class="main-wrapper">



		<?php include 'includes/header.php'; ?>
		<?php include 'includes/sidebar.php'; ?>

		<!-- Page Wrapper -->
		<div class="page-wrapper">
			<div class="content">

				<!-- Breadcrumb -->
				<div class="d-md-flex d-block align-items-center justify-content-between page-breadcrumb mb-3">
					<div class="my-auto mb-2">
						<h2 class="mb-1">Dashboard</h2>
						<nav>
							<ol class="breadcrumb mb-0">
								<li class="breadcrumb-item">
									<a href="/index"><i class="ti ti-smart-home"></i></a>
								</li>
								<li class="breadcrumb-item">
									Dashboard
								</li>
								<li class="breadcrumb-item active" aria-current="page">Dashboard</li>
							</ol>
						</nav>
					</div>
					<!-- <div class="d-flex my-xl-auto right-content align-items-center flex-wrap ">
					<div class="me-2 mb-2">
						<div class="dropdown">
							<a href="javascript:void(0);" class="dropdown-toggle btn btn-white d-inline-flex align-items-center" data-bs-toggle="dropdown">
								<i class="ti ti-file-export me-1"></i>Export
							</a>
							<ul class="dropdown-menu  dropdown-menu-end p-3">
								<li>
									<a href="javascript:void(0);" class="dropdown-item rounded-1"><i class="ti ti-file-type-pdf me-1"></i>Export as PDF</a>
								</li>
								<li>
									<a href="javascript:void(0);" class="dropdown-item rounded-1"><i class="ti ti-file-type-xls me-1"></i>Export as Excel </a>
								</li>
							</ul>
						</div>
					</div>
					<div class="mb-2">
						<a href="#" data-bs-toggle="modal" data-bs-target="#add_leaves" class="btn btn-primary d-flex align-items-center"><i class="ti ti-circle-plus me-2"></i>Add Leave</a>
					</div>
					<div class="head-icons ms-2">
						<a href="javascript:void(0);" class="" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Collapse" id="collapse-header">
							<i class="ti ti-chevrons-up"></i>
						</a>
					</div>
				</div> -->
				</div>
				<!-- /Breadcrumb -->

				<!-- Leaves Info -->
				<div class="row">
					<div class="col-xl-4 col-md-6">
						<div class="card flex-fill">
							<div class="card-body text-center">
								<span class="avatar py-2">
									<img src="assets/img/ticketing/icons/close-tickets.png" class="img-fluid">
								</span>
								<h6 class="fs-22 fw-medium text-dark mb-1">2458</h6>
								<span class="fs-14 text-body">Total No. of Tickets</span>

								<!-- <a href="" class="link-default">View Details</a> -->
							</div>
						</div>
					</div>

					<div class="col-xl-4 col-md-6">
						<div class="card flex-fill">
							<div class="card-body text-center">
							<span class="avatar py-2">
									<img src="assets/img/ticketing/icons/new-tickets.png" class="img-fluid">
								</span>
								<h6 class="fs-22 fw-medium text-dark mb-1">2458</h6>
								<span class="fs-14 text-body">New Tickets</span>

								<!-- <a href="" class="link-default">View Details</a> -->
							</div>
						</div>
					</div>

					<div class="col-xl-4 col-md-6">
						<div class="card flex-fill">
							<div class="card-body text-center">
							<span class="avatar py-2">
									<img src="assets/img/ticketing/icons/Total-tickets.png" class="img-fluid">
								</span>
								<h6 class="fs-22 fw-medium text-dark mb-0">2458</h6>
								<span class="fs-14 text-body">Closed Tickets</span>

								<!-- <a href="" class="link-default">View Details</a> -->
							</div>
						</div>
					</div>

					<!-- <div class="col-xl-3 col-md-6">
						<div class="card flex-fill">
							<div class="card-body text-center">
								<span class="avatar rounded-circle bg-primary  mb-2">
									<i class="ti ti-calendar-share fs-16"></i>
								</span>
								<h6 class="fs-22 fw-medium text-dark mb-1">2458</h6>
								<span class="fs-14 text-body">Total No. of Tickets</span>
							
								<a href="" class="link-default">View Details</a>
							</div>
						</div>
					</div> -->

				</div>
				<!-- /Leaves Info -->


				<div class="row mb-4">
					<div class="col-xl-8 col-md-8">
						<div class="card flex-fill">
						<div class="card-header">
								<div class="d-flex align-items-center justify-content-between flex-wrap">
								<h3 class="card-title">Estimated of solved Tickets</h3>
									<div class="dropdown mb-2">
                                    <a href="javascript:void(0);" class="btn btn-white border btn-sm d-inline-flex align-items-center" data-bs-toggle="dropdown">
                                        <i class="ti ti-calendar me-1"></i>Last 01 Years 
                                    </a>
                                    <ul class="dropdown-menu  dropdown-menu-end p-3">
                                        <li>
                                            <a href="javascript:void(0);" class="dropdown-item rounded-1">This Month</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);" class="dropdown-item rounded-1">This Week</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);" class="dropdown-item rounded-1">Today</a>
                                        </li>
                                    </ul>
                                </div>
								</div>
							</div>
							<div class="card-body">
								<div class="est-img">
							 <img src="assets/img/ticketing/chart1.png" class="img-fluid">
							 </div>

							</div>
						</div>
					</div>
					<div class="col-xxl-4 col-lg-4">
						<div class="card flex-fill">
							<div class="card-header">
								<div class="d-flex align-items-center justify-content-between flex-wrap">
									<h3 class="card-title">Employees with most tickets</h3>
									<div class="dropdown mb-2">
                                    <a href="javascript:void(0);" class="btn btn-white border btn-sm d-inline-flex align-items-center" data-bs-toggle="dropdown">
                                        <i class="ti ti-calendar me-1"></i>Today
                                    </a>
                                    <ul class="dropdown-menu  dropdown-menu-end p-3">
                                        <li>
                                            <a href="javascript:void(0);" class="dropdown-item rounded-1">This Month</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);" class="dropdown-item rounded-1">This Week</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);" class="dropdown-item rounded-1">Today</a>
                                        </li>
                                    </ul>
                                </div>
								</div>
							</div>
							<div class="card-body" style="min-height:300px;overflow-y:auto;">
							<div class="table-responsive">
                                <table class="table mb-0">
                                    <thead class="text-start">
                                        <tr>
                                            <th>Employees name</th>
                                            <th>Tickets</th>
                                            <th>Department</th>
											<!-- <th>Last Reply</th> -->
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Jonny Bratisow</td>
                                            <td>17 Tickets</td>
                                            <!-- <td><img src="assets/images/" class="img-fluid"> </td> -->
											<td>Brand</td>
										</tr>

										<tr>
                                            <td>James Anderson</td>
                                            <td>14 Tickets</td>
                                            <!-- <td><img src="assets/images/" class="img-fluid"> </td> -->
											<td>Software</td>
										</tr>

										<tr>
                                            <td>Joe Root</td>
                                            <td>12 Tickets</td>
                                            <!-- <td><img src="assets/images/" class="img-fluid"> </td> -->
											<td>Sales</td>
										</tr>

										<tr>
                                            <td>Jos buttler</td>
                                            <td>11 Tickets</td>
                                            <!-- <td><img src="assets/images/" class="img-fluid"> </td> -->
											<td>Admin</td>
										</tr>

										<tr>
                                            <td>Ben stokes</td>
                                            <td>11 Tickets</td>
                                            <!-- <td><img src="assets/images/" class="img-fluid"> </td> -->
											<td>Software</td>
										</tr>
										<tr class="">
                                            <td>Eoin Morgan</td>
                                            <td>11 Tickets</td>
                                            <!-- <td><img src="assets/images/" class="img-fluid"> </td> -->
											<td>Brand</td>
										</tr>
                                       
                                    </tbody>
                                </table>
                            </div>

							</div>
						</div>
					</div>
				</div>


				<div class="row">
					<div class="col-xll-12 col-12">
					<div class="card bg-transparent border border-0 shadow-none">
							<div class="card-header bg-transparent ">
								<div class="d-flex align-items-center justify-content-between flex-wrap">
									<div class="flex-column">
									<h3 class="card-title">All Support Tickets</h3>
									<p class="text-body fs-12">List of ticket open by Custome</p>
									</div>
									<div class="dropdown mb-2">
                                    <a href="javascript:void(0);" class="btn btn-white border btn-sm d-inline-flex align-items-center" data-bs-toggle="dropdown">
                                        <i class="ti ti-calendar me-1"></i>Today
                                    </a>
                                    <ul class="dropdown-menu  dropdown-menu-end p-3">
                                        <li>
                                            <a href="javascript:void(0);" class="dropdown-item rounded-1">This Month</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);" class="dropdown-item rounded-1">This Week</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0);" class="dropdown-item rounded-1">Today</a>
                                        </li>
                                    </ul>
                                </div>
								</div>
							</div>
							<div class="card-body p-0">
                    <div class="table-responsive table-responsive-lg">
                        <table class="table ">
                            <thead class="thead-light">
                                <tr>
                                   
                                    <th>ID</th>
                                    <th>Request Name</th>
                                    <th>Subjects</th>
                                    <th>Status</th>
                                    <th>Priority</th>
                                    <th>Assignee</th>
                                    <th>Create Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
									<td>
										1
									</td>
                                   <td>
                                   <div class="d-flex align-items-center">
                                    <a href="assets/img/users/user-32.webp" data-fancybox="gallery" data-caption="" class="avatar avatar-md">
                                        <img src="assets/img/users/user-32.webp" class="img-fluid rounded-circle" alt="img">
                                    </a>
                                        <div class="ms-2">
                                            <p class="text-dark mb-0"><a href="#" data-bs-toggle="modal" data-bs-target="#view_details">Aorn Finch</a></p>
                                            <!-- <span class="fs-12">Finance</span> -->
                                        </div>
                                    </div>
                                
                                   </td>
								 
								   <td>
                                   <p class="fs-14 mb-0">I need help with adding a New Contact</p>
                                   </td>
								   <td>
								   <p class="fs-13 d-inline-flex align-items-center mb-1"><i class="ti ti-circle-filled fs-10 me-1 text-warning"></i>Ongoing</p>
								   </td>
								   <td>
                                            <span class="badge bg-soft-primary">Low</span>
                                    </td>
                                  
                                   <td>
                                   <p class="fs-14  mb-0">Michela Stark</p>
                                   </td>
                                  
                                    <td>
                                        20 Oct 2018
                                    </td>
                                </tr>		

								<tr>
									<td>
										1
									</td>
                                   <td>
                                   <div class="d-flex align-items-center">
                                    <a href="assets/img/users/user-32.webp" data-fancybox="gallery" data-caption="" class="avatar avatar-md">
                                        <img src="assets/img/users/user-30.webp" class="img-fluid rounded-circle" alt="img">
                                    </a>
                                        <div class="ms-2">
                                            <p class="text-dark mb-0"><a href="#" data-bs-toggle="modal" data-bs-target="#view_details">David Warner</a></p>
                                            <!-- <span class="fs-12">Finance</span> -->
                                        </div>
                                    </div>
                                
                                   </td>
								 
								   <td>
                                   <p class="fs-14 mb-0">I need help with adding a New Contact</p>
                                   </td>
								   <td>
								   <p class="fs-13 d-inline-flex align-items-center mb-1"><i class="ti ti-circle-filled fs-10 me-1 text-warning"></i>Closes</p>
								   </td>
								   <td>
                                            <span class="badge bg-soft-warning">Warning</span>
                                    </td>
                                  
                                   <td>
                                   <p class="fs-14  mb-0">Steve Smith</p>
                                   </td>
                                  
                                    <td>
                                        20 Oct 2018
                                    </td>
                                </tr>		
                              
                            </tbody>
                        </table>
                    </div>
					</div>
				</div>



			</div>
			<?php include 'includes/footer.php'; ?>
		</div>
		<!-- /Page Wrapper -->



	</div>
	<!-- /Main Wrapper -->

	<?php include 'includes/script.php'; ?>

</body>

</html>